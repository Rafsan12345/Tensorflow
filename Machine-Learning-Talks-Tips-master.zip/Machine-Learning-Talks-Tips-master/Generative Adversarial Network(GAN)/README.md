# Generative Adversarial Network(GAN)


## Coding Implementation
GANs are a hot topic of research today in the field of deep learning. Popularity has soared with this architecture style, with its ability to produce generative models that are typically hard to learn. There are a number of advantages to using this architecture: it generalizes with limited data, conceives new scenes from small datasets, and makes simulated data look more realistic.
For implementing GAN we used Keras Framework



## 𝗽𝗲𝗿𝘀𝗼𝗻𝗮𝗹 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 :
𝐏𝐡𝐨𝐧𝐞:   (+880) 1772905097 (Whatsapp)
𝘔𝘢𝘪𝘭:     jahidnoyon36@gmail.com
𝘍𝘣:         https://www.facebook.com/jahid22angry...

𝘗𝘢𝘨𝘦 :    https://www.facebook.com/jahid2ml
𝘓𝘪𝘯𝘬𝘦𝘥𝘐𝘕 :    https://www.linkedin.com/in/hellojahid
𝘎𝘪𝘵𝘩𝘶𝘣:  https://github.com/hellojahid