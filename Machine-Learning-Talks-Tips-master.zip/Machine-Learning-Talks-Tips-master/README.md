This repo have all code and jupyter notebook associate with  Machine-Learning-Talks-Tips 
